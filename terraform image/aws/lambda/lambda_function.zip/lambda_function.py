def lambda_handler(event, context):
    print("Hello, Patterns Team!")
    return "Hello, Patterns Team!"